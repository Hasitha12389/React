import React from 'react';
import PropTypes from 'prop-types';
import Card from './Card';

const CardList = ({ cards }) => {
    return (
        <div className = "card-list">
            {cards.map((card, index) => (
                <Card key={index} title={card.title} content={card.content} />
            ))}
        </div>
    );
};

CardList.propTypes = {
    cards: PropTypes.arrayOf(
        PropTypes.shape({
            title: PropTypes.string.isRequired,
            content: PropTypes.string.isRequired,
        })
    ).isRequired,
};

export default CardList;

/*
///// css for card ////////
.card-list {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
}

.card {
  border: 1px solid #ccc;
  border-radius: 8px;
  padding: 16px;
  margin: 8px;
  width: 200px;
  box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.card h3{
  margin-top: 0;
}

.card p {
  margin-bottom: 0;
}

*/

/* In App.js 
const cards = [
  {title: 'Card 1', content: "This is the content of card 1."},
  {title: 'Card 2', content: "This is the content of card 2."},
  {title: 'Card 3', content: "This is the content of card 3."},
];

/// component call
 <CardList cards={cards}/>

*/