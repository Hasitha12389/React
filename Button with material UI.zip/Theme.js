import { createTheme } from "@mui/material";

const theme = createTheme({
  palette: {
    primary: {
        main: '#1976d2',   // Customize the primary color
    },
    secondary: {
        main: '#dc004e',  // Customize the secondary color
    },
  },
  typography: {
    button: {
        textTransform: 'none',   // Prevent button text from being uppercase
    },
  },
});

export default theme;