import React from 'react';
import { Button } from '@mui/material';

const CutomButton = () => {
    const handleClick = () => {
        alert("Button clicked!");
    };
  return (
    <Button varient="contained" color="primary" onClick={handleClick}>
        Click Me
    </Button>
  );
};

export default CutomButton;

/* CSS
.Button {
border: 1px solid black;
border-radius: 15px;
background-color: yellow;
padding: 2px;
margin: 10px;
margin-left: 50%;
width: 80px;
text-align: center;
}

App.js content

import { ThemeProvider } from '@emotion/react';
import theme from './components/Theme';
import CutomButton from './components/CustomButton';

 <ThemeProvider theme={theme}>
  <div className="App">
     <header className="App-header">
      <h1>Custom Button</h1>
     </header>
     <main>
      <div  className='Button'>
      <CutomButton/>
      </div>
     </main>
    </div>
    </ThemeProvider>
*/